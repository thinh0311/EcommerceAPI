﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API.Migrations
{
    public partial class Add_CTPN : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "NguyenLieu",
                columns: table => new
                {
                    MaNguyenLieu = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenNguyenLieu = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NguyenLieu", x => x.MaNguyenLieu);
                });

            migrationBuilder.CreateTable(
                name: "CTPN",
                columns: table => new
                {
                    MaPN = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    MaNguyenLieu = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    KhoiLuong = table.Column<double>(type: "float", nullable: false),
                    Gia = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CTPN", x => new { x.MaPN, x.MaNguyenLieu });
                    table.ForeignKey(
                        name: "FK_CTPN_NguyenLieu",
                        column: x => x.MaNguyenLieu,
                        principalTable: "NguyenLieu",
                        principalColumn: "MaNguyenLieu",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CTPN_PhieuNhap",
                        column: x => x.MaPN,
                        principalTable: "PhieuNhap",
                        principalColumn: "MaPN",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CTPN_MaNguyenLieu",
                table: "CTPN",
                column: "MaNguyenLieu");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CTPN");

            migrationBuilder.DropTable(
                name: "NguyenLieu");
        }
    }
}
