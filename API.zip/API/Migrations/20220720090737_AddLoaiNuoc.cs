﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API.Migrations
{
    public partial class AddLoaiNuoc : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "MoTa",
                table: "SanPham",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<Guid>(
                name: "MaLoaiNuoc",
                table: "SanPham",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.CreateTable(
                name: "LoaiNuoc",
                columns: table => new
                {
                    MaLoaiNuoc = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TenLoaiNuoc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MoTa = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HinhAnh = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoaiNuoc", x => x.MaLoaiNuoc);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SanPham_MaLoaiNuoc",
                table: "SanPham",
                column: "MaLoaiNuoc");

            migrationBuilder.AddForeignKey(
                name: "FK_SanPham_LoaiNuoc",
                table: "SanPham",
                column: "MaLoaiNuoc",
                principalTable: "LoaiNuoc",
                principalColumn: "MaLoaiNuoc",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SanPham_LoaiNuoc",
                table: "SanPham");

            migrationBuilder.DropTable(
                name: "LoaiNuoc");

            migrationBuilder.DropIndex(
                name: "IX_SanPham_MaLoaiNuoc",
                table: "SanPham");

            migrationBuilder.DropColumn(
                name: "MaLoaiNuoc",
                table: "SanPham");

            migrationBuilder.AlterColumn<string>(
                name: "MoTa",
                table: "SanPham",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}
