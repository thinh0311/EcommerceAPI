﻿using System.ComponentModel.DataAnnotations;

namespace API.Data
{
    public class KhuyenMai
    {
        public KhuyenMai()
        {
        }
        public Guid MaKM { get; set; }

        [MaxLength(50)]
        public string TenKM { get; set; }

        public DateTime NgayBatDau { get; set; }
        public DateTime NgayKetThuc { get; set; }
        public int PhanTramGiam { get; set; }
        public string? MoTa { get; set; }
        public Guid MaNV { get; set; }

        public virtual NhanVien NhanVien_owner { get; set; }


    }
}
