﻿using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    public class Quyen_Model
    {
        
       
        public string TenQuyen { get; set; } 

       
    }
}
