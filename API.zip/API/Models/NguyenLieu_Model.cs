﻿using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    public class NguyenLieu_Model
    {
        

        
        public string TenNguyenLieu { get; set; }

        

    }
}
