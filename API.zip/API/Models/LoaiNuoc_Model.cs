﻿using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    public class LoaiNuoc_Model
    {
        

        
       
        public string TenLoaiNuoc { get; set; }
        public string? MoTa { get; set; }
        public string HinhAnh { get; set; }

        
    }
}
