﻿using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    public class CongTyShip_Model
    {
        public string TenCongTy { get; set; }
        public string DiaChi { get; set; }
        public string SDT { get; set; }
        public string MoTa { get; set; }
    }
}
