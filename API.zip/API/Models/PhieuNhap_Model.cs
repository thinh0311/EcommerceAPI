﻿using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    
    public class PhieuNhap_Model
    {
       

        
       
        public Guid MaNV { get; set; }

       
    }
}
