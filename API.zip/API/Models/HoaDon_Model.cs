﻿namespace API.Models
{
    public class HoaDon_Model
    {
        
        
       
  
        public Guid MaDonHang { get; set; }
        public Guid MaNV { get; set; }

        
        
    }
}
